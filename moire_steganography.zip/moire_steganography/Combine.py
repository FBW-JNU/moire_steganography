import numpy as np
import torch
import torch.nn as nn
from model.decoder import Decoder
from model.Steganalyzer import Srnet as Steganalyzer
from model.encoder import Encoder
from model.generator import MoireCNN

#hidden的encoder已经拓维
# def expand_messages(message):
#     # input_message=[batch_size,len]
#     # output_message=[batch_size,len,256,256]
#     expanded_message = message.unsqueeze(-1)
#     expanded_message.unsqueeze_(-1)
#     expanded_message = expanded_message.expand(-1,-1, 256, 256)
#     return expanded_message

class combine_model:
    def __init__(self,device: torch.device):

        super(combine_model, self).__init__()

        # test3&4，分用encoder
        self.g = MoireCNN(input_channel=6).to(device)
        self.encoder1=Encoder().to(device)
        self.encoder2 = Encoder().to(device)
        self.encoder3 = Encoder().to(device)
        self.encoder4 = Encoder().to(device)
        self.encoder5 = Encoder().to(device)
        self.s = Steganalyzer().to(device)
        self.decoder=Decoder().to(device)

        # 固定噪声层参数
        checkpoint=torch.load('model/moire_checkpoint_16.pth',map_location=device)
        # 加载预训练g网络参数
        self.g.load_state_dict((checkpoint['Generator']))
        # 冻结g网络的参数
        for name, param in self.g.named_parameters():
            param.requires_grad = False

        # test3&4
        params=list(self.encoder1.parameters())+list(self.decoder.parameters())+list(self.encoder5.parameters())\
               +list(self.encoder2.parameters())+list(self.encoder3.parameters())+list(self.encoder4.parameters())
        self.optimizer_enc_dec=torch.optim.Adam(params)
        self.optimizer_s = torch.optim.Adam(self.s.parameters())

        self.device = device

        self.bce_with_logits_loss = nn.CrossEntropyLoss().to(device)
        self.mse_loss = nn.MSELoss().to(device)

    def train_on_batch(self, batch: list):

        clean_image,message = batch
        init_noise=torch.normal(0,1,clean_image.shape).to(self.device)
        # test1&2
        # self.encoder.train()
        # test3&4
        self.encoder1.train()
        self.encoder2.train()
        self.encoder3.train()
        self.encoder4.train()
        self.encoder5.train()
        self.decoder.train()
        self.s.train()

        with torch.enable_grad():
            # ---------------- Train the Steganalyzer -----------------------------
            self.optimizer_s.zero_grad()

            init_clean=torch.cat([init_noise,clean_image],dim=1)
            x1 , x2 , x3 , x4 , x5=self.g(init_clean)
            x=x1 + x2 + x3 + x4 + x5
            # test3&4
            x1_encoded=self.encoder1(x1,message)
            x2_encoded = self.encoder2(x2, message)
            x3_encoded = self.encoder3(x3, message)
            x4_encoded = self.encoder4(x4, message)
            x5_encoded = self.encoder5(x5, message)

            x_encoded=x1_encoded+x2_encoded+x3_encoded+x4_encoded+x5_encoded

            # 隐写分析鉴别器s
            x_encoded_reshape=torch.reshape(x_encoded,(-1,1,256,256))
            D_output_f=self.s(x_encoded_reshape.detach())
            D_loss_f=self.bce_with_logits_loss(D_output_f,torch.zeros(D_output_f.size()).to(self.device))

            x_reshape=torch.reshape(x,(-1,1,256,256))
            D_output_r = self.s(x_reshape.detach())
            D_loss_r = self.bce_with_logits_loss(D_output_r, torch.ones(D_output_r.size()).to(self.device))

            s_loss = D_loss_r+ D_loss_f
            s_loss.backward()
            self.optimizer_s.step()

            # -----------------------  Train the encoder_decoder   -----------------------------
            self.optimizer_enc_dec.zero_grad()
            x_encoded_reshape = torch.reshape(x_encoded, (-1, 1, 256, 256))
            g_adv_out=self.s(x_encoded_reshape)
            g_loss_adv = self.bce_with_logits_loss(g_adv_out, torch.ones(g_adv_out.size()).to(self.device))


            image_encoded=clean_image+x_encoded
            image_encoded=image_encoded.clamp(0,1)
            decoded_message = self.decoder(image_encoded)
            g_loss_dec = self.mse_loss(decoded_message, message)
            # test1&3
            x1_loss = self.mse_loss(x1,x1_encoded)
            x2_loss = self.mse_loss(x2, x2_encoded)
            x3_loss = self.mse_loss(x3, x3_encoded)
            x4_loss = self.mse_loss(x4, x4_encoded)
            x5_loss = self.mse_loss(x5, x5_encoded)
            x_loss=x1_loss+x2_loss+x3_loss+x4_loss+x5_loss

            # test1的x_loss是0.7，test2,3,4,是1
            en_de_loss = 1e-3*g_loss_adv+1*g_loss_dec+1*x_loss
            en_de_loss.backward()
            self.optimizer_enc_dec.step()


        # decoded_messages转到cpu numpy.取整.预定在（0,1）之间
        decoded_rounded = decoded_message.detach().cpu().numpy().round().clip(0, 1)
        # 计算平均错误率
        bitwise_avg_err = np.sum(np.abs(decoded_rounded - message.detach().cpu().numpy())) / (
                clean_image.shape[0] * message.shape[1])

        losses = {
            's_loss': s_loss.item(),
            'en_de_loss': en_de_loss.item(),
            'bitwise_error': bitwise_avg_err,
        }

        image_moire=clean_image+x
        return losses, (clean_image,image_moire.clamp(0,1),image_encoded)

    def validate_on_batch(self, batch: list):
        # 对由图像和消息组成的单批数据运行验证

        clean_image,message = batch
        init_noise=torch.normal(0,1,clean_image.shape).to(self.device)

        # test3&4
        self.encoder1.eval()
        self.encoder2.eval()
        self.encoder3.eval()
        self.encoder4.eval()
        self.encoder5.eval()
        self.decoder.eval()
        self.s.eval()
        self.g.eval()

        with torch.no_grad():

            init_clean=torch.cat([init_noise,clean_image],dim=1)
            x1 , x2 , x3 , x4 , x5=self.g(init_clean)
            x=x1 + x2 + x3 + x4 + x5

            # test3&4
            x1_encoded=self.encoder1(x1,message)
            x2_encoded = self.encoder2(x2, message)
            x3_encoded = self.encoder3(x3, message)
            x4_encoded = self.encoder4(x4, message)
            x5_encoded = self.encoder5(x5, message)

            x_encoded=x1_encoded+x2_encoded+x3_encoded+x4_encoded+x5_encoded

            # 隐写分析鉴别器s
            x_encoded_reshape=torch.reshape(x_encoded,(-1,1,256,256))
            D_output_f=self.s(x_encoded_reshape.detach())
            D_loss_f=self.bce_with_logits_loss(D_output_f,torch.zeros(D_output_f.size()).to(self.device))

            x_reshape=torch.reshape(x,(-1,1,256,256))
            D_output_r = self.s(x_reshape.detach())
            D_loss_r = self.bce_with_logits_loss(D_output_r, torch.ones(D_output_r.size()).to(self.device))

            s_loss = D_loss_r+ D_loss_f

            x_encoded_reshape = torch.reshape(x_encoded, (-1, 1, 256, 256))
            g_adv_out=self.s(x_encoded_reshape)
            g_loss_adv = self.bce_with_logits_loss(g_adv_out, torch.ones(g_adv_out.size()).to(self.device))


            image_encoded=clean_image+x_encoded
            image_encoded=image_encoded.clamp(0,1)
            decoded_message = self.decoder(image_encoded)
            g_loss_dec = self.mse_loss(decoded_message, message)
            # test1&3
            x1_loss = self.mse_loss(x1,x1_encoded)
            x2_loss = self.mse_loss(x2, x2_encoded)
            x3_loss = self.mse_loss(x3, x3_encoded)
            x4_loss = self.mse_loss(x4, x4_encoded)
            x5_loss = self.mse_loss(x5, x5_encoded)
            x_loss=x1_loss+x2_loss+x3_loss+x4_loss+x5_loss

            # test1的x_loss是0.7，test2,3,4,是1
            en_de_loss = 1e-3*g_loss_adv+1*g_loss_dec+1*x_loss

        # decoded_messages转到cpu numpy.取整.预定在（0,1）之间
        decoded_rounded = decoded_message.detach().cpu().numpy().round().clip(0, 1)
        # 计算平均错误率
        bitwise_avg_err = np.sum(np.abs(decoded_rounded - message.detach().cpu().numpy())) / (
                clean_image.shape[0] * message.shape[1])

        losses = {
            's_loss': s_loss.item(),
            'en_de_loss': en_de_loss.item(),
            'bitwise_error': bitwise_avg_err,
        }

        image_moire=clean_image+x
        return losses, (clean_image,image_moire.clamp(0,1),image_encoded)

